#!/usr/local/bin/perl



## Author : Kodath.Roshan@oracle.com
#  Date of Compilation: 8th August 2014

use File::Basename;
use Cwd;


our $scriptDir = dirname($0);


our($podname,$tenantname,$podadmin,$tenantadmin,%inputhash,%srvcparamhash,$oamserver,$idmurl,$oamserveruser,$oamserverpassword,$feederfile);
our($script1,$script2,$script3,$script4,$script5,$script6,$script7,$dataloaduser,$group1,$group2);
our($daasprop,$daaspwds,$autoworkdir,$daasproptemp,$daaspwdtemp);
our(%ExportParamTable);

$ExportParamTable{EXIT_STATUS}='SUCCESS';

operation();

print "This Run result : \t $ExportParamTable{EXIT_STATUS}\n";


exit $exit_value;


################# Program Subroutines For Block Logic ################
#
# ADD YOUR CODE BELOW
#
# Subroutine operation() is to accomplish the goal of this block - do the real job
# and generate values for all the exported parameters listed in block definition.
# The workdir of this block is $RuntimeParamTable{WORKDIR}, temporary files and subdir
# can be created in this workdir as needed
#
sub operation
{

setvars();

ReadandParseInputFile();

if(ExecGeneratePodNamepy($idmurl,$oamserver,$srvctemp,$autoworkdir) < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}

print "sleeping for 10s...."; sleep 10;

if(ExecRegPodScriptpy($oamserver, 'createMTService',$oamserveruser,$oamserverpassword) < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}
print "sleeping for 10s...."; sleep 10;

if(ExecRegPodScriptpy($oamserver, 'getTenantWSMKeyStore',$oamserveruser,$oamserverpassword) < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}
print "sleeping for 10s...."; sleep 10;


if(ExecRegPodScriptpy($oamserver, 'createTenant',$oamserveruser,$oamserverpassword) < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}
print "sleeping for 10s...."; sleep 10;

if(ExecRegPodScriptpy($oamserver, 'createService',$oamserveruser,$oamserverpassword) < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}
 
if(Readsrvcparamfile($oamserver) < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}
print "$podname $tenantname $podadmin $tenantadmin\n";

if(ExecMakeJsonpy($oamserver,$podname,$autoworkdir) < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}

if(Execreadnreplacepl('altprop',"$daasprop") < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}
if(Execreadnreplacepl('altpass',"$daaspwds") < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}

if(Execmodifyldappy($idmurl,$podadmin,'obpasswordchangeflag') < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;} 
if(Execmodifyldappy($idmurl,$tenantadmin,'obpasswordchangeflag') < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;} 

$group1 = "$podname" . "_DATASERVICE_CCONSOLE_APPID_ROLE";
$group2 = "$podname" . ".dataservice_user";

if(Execcreateauserinldappy($idmurl,$dataloaduser) < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}

if(Execaddtoagroupldappy($idmurl,$group1,$tenantname) < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}
if(Execaddtoagroupldappy($idmurl,$group2,$tenantname) < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}
 

if(MakeotherAlts() < 0) {$ExportParamTable{EXIT_STATUS}='FAILURE'; $exit_value=255; return;}

exportVariables();


}

# 
#  ADD YOUR SUPPORTING ROUTINE(S) BELOW, IF ANY
#
#

sub setvars
{

$feederfile = "feeder.txt"; 
$script1 = "${scriptDir}/GeneratePodName.py";
$script2 = "${scriptDir}/ExecRegPodScript.py";
$script3 = "${scriptDir}/parseidmdmp.py";
$script4 = "${scriptDir}/readnreplace.pl";
$script5 = "${scriptDir}/modifyattributeldap.py";
$script6 = "${scriptDir}/createauserinldap.py";
$script7 = "${scriptDir}/addtoagroupldap.py";
$autoworkdir = "/u01/common_multinode/IDM/IDMScripts/sid";
$daasprop = "$autoworkdir/propfromdmp.txt";
$daaspwds = "$autoworkdir/pwdsfromdmp.txt";
$daasproptemp = "${scriptDir}/DaaSPropTemplate.txt";
$daaspwdtemp  = "${scriptDir}/pwds_22.py_template";
$srvctemp  = "${scriptDir}/srvc.param";
$regscr = "${scriptDir}/RegisterPod.py";
#print "$regscr\n";exit(1);

system("cp -f $daasproptemp $autoworkdir");
system("cp -f $daaspwdtemp  $autoworkdir");

}






sub ReadandParseInputFile
{
open(IN, "<$feederfile") || die "Cannot opne file\n";

while(<IN>)
{
  chomp;
 (my $lvalue, my $rvalue) = split(/=/, $_ , 2);
  $inputhash{$lvalue} = $rvalue;
}
      close(IN);
  
      $oamserver = $inputhash{'OAM-SERVER'};
      $idmurl = $inputhash{'LDAP-URL'};
      $oamserveruser = $inputhash{'OAM-SERVER-USER'};
      $oamserverpassword = $inputhash{'OAM-SERVER-PASSWORD'};
      $dataloaduser = $inputhash{'DATALOAD-USER'};
      $certurl = $inputhash{'CERTIFICATE-URL'};
}




sub Readsrvcparamfile
{

my $oam = $_[0];

if(-e "/net/$oam/scratch/aime/tmpsrvcparam")
  {
      open(IN, "</net/$oamserver/scratch/aime/tmpsrvcparam") || die "Cannot opne file\n";
      while(<IN>)
        {
            chomp;
           (my $lvalue, my $rvalue) = split(/:/, $_ , 2);
           $srvcparamhash{$lvalue} = $rvalue;
        } 
  
     close(IN);

  

$podname = $srvcparamhash{'IDSTORE_SERVICE_NAME'};
$podname =~ s/\s+//g;
$tenantname = $srvcparamhash{'IDSTORE_TENANT_NAME'};
$tenantname =~ s/\s+//g;
$podadmin = $srvcparamhash{'IDSTORE_SERVICE_ADMIN'};
$podadmin =~ s/\s+//g;
$tenantadmin = $srvcparamhash{'IDSTORE_TENANT_ADMIN'};
$tenantadmin =~ s/\s+//g;
  }

else
  {
    return -1;
  }

}






sub ExecGeneratePodNamepy
{

my $idm = $_[0];
my $oam = $_[1];
my $srvctmp = $_[2];
my $workdir = $_[3];

my $retstat = system("python $script1 $idm $oam $srvctmp $workdir");
if($retstat > 0) {return -1;}


}



sub ExecRegPodScriptpy
{
my $oam =  $_[0];
my $mode = $_[1];
my $user = $_[2];
my $pass = $_[3];

my $retstat;

$retstat = system("cp -f $regscr /net/$oam/scratch/aime/");
if($retstat > 0) {return -1;}

$retstat = system("python $script2 $oam $mode $user $pass");
if($retstat > 0) {return -1;}

}


sub ExecMakeJsonpy
{
system("rm -f props");
system("rm -f passwds");

my $oam = $_[0];
my $pod = $_[1];
my $workdir = $_[2];
my $propfile = "$workdir/propfromdmp.txt";
my $pwdfile = "$workdir/pwdsfromdmp.txt";
my $dmpfile = $pod . ".dmp";

$dmpfile =~ s/\s+//g;

my $retstat = system("python $script3 /net/$oam/scratch/aime/$dmpfile   $propfile  $pwdfile");
if($retstat > 0) {return -1;}


}


sub Execreadnreplacepl
{
my $altwhat = $_[0];
my $replacefrom = $_[1];
my $destdir = $autoworkdir; 

my $retstat = system("perl $script4 $altwhat $replacefrom $destdir");
if($retstat > 0) {return -1;}

}


sub Execmodifyldappy
{
my $idm = $_[0];
my $cn  = $_[1];
my $attrtomod = $_[2];

my $retstat = system("python $script5 $idm  $cn $attrtomod");
if($retstat > 0) {return -1;}
}

sub Execcreateauserinldappy
{
$idm = $_[0];
$loaduser = $_[1];
my $filter = "'(&(cn=Users)(orclmttenantuname=$tenantname))'";
my $attr = "orclMTTenantGuid";
my $retstat = system("python $script6 $idm $filter $attr $tenantname $loaduser");
if($retstat > 0) {return -1;}
}


sub Execaddtoagroupldappy
{
my $idm = $_[0];
my $group = $_[1];
my $tenan = $_[2];
my $retstat = system("python $script7 $idm $group $dataloaduser $tenan");
if($retstat > 0) {return -1;}
}

sub MakeotherAlts
{

my $retstat = system("sed -i -re '/CERTIFICATE_URL/ s#=(.+)#=$certurl#' $autoworkdir/DaaSPropTemplate.txt");
if($retstat > 0) {return -1;}

my $retstat = system("sed -i -re '/DAAS_USER/ s#=(.+)#=$dataloaduser#' $autoworkdir/DaaSPropTemplate.txt");
if($retstat > 0) {return -1;}

my $retstat = system("sed -i -re '/DAAS_IDM_TENANT/ s#=(.+)#=$tenantname#' $autoworkdir/DaaSPropTemplate.txt");
if($retstat > 0) {return -1;}

my $retstat = system("sed -i -re '/curator_ui_username/ s#=(.+)#=$dataloaduser#' $autoworkdir/DaaSPropTemplate.txt");
if($retstat > 0) {return -1;}

my $retstat = system("sed -i -re '/curator_ui_password/ s#=(.+)#=Welcome2#' $autoworkdir/DaaSPropTemplate.txt");
if($retstat > 0) {return -1;}

}

sub exportVariables 
{
        $ExportParamTable{TENANT} = $tenantname;
        $ExportParamTable{TENANTADMIN} = $tenantadmin;
        $ExportParamTable{SERVICE} = $podname;
        $ExportParamTable{TENANTADMPWD} = 'Fusionapps1';
        
}

