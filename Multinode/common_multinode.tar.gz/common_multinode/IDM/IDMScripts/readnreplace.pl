#!/usr/local/bin/perl

$whichfile = $ARGV[0];
$destdir = $ARGV[2];
if($whichfile eq 'altprop') 
{
   $destfile = "$destdir/DaaSPropTemplate.txt";
   #print $destfile;
}
elsif($whichfile eq 'altpass')
{
   $destfile = "$destdir/pwds_22.py_template";
}
open(fh, "<$ARGV[1]") || die "Cannot open file\n";

while(<fh>)
{
($lvalue,$rvalue) = split(/=/, $_,2);
chomp($lvalue);
chomp($rvalue);


system("sed -i -re '/$lvalue/ s#=(.+)#=$rvalue#' $destfile");

}

close(fh);
