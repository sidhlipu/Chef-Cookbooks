export filter="'(&(cn=Users)(orclmttenantuname=PDKQATENANT01))'"
export attr="orclMTTenantGuid"
export tenantname="PDKQATENANT01"
export idm=ldap://slc04bgn.us.oracle.com:3060
export loaduser=testuser01
export script6=/scratch/aime/IDM/IDMScripts/createauserinldap.py
echo python  $script6  `echo $idm` `echo $filter` `echo $attr` `echo $tenantname` `echo $loaduser`
python  $script6  `echo $idm` `echo $filter` `echo $attr` `echo $tenantname` `echo $loaduser`

